// ignore_for_file: deprecated_member_use

import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:iconsax_plus/iconsax_plus.dart';
import 'package:shamsi_date/shamsi_date.dart';
import 'package:simo_learn/presentation/widgets/_widgets.dart';
import 'package:simo_learn/presentation/widgets/re_header.dart';
import 'package:simo_learn/utils/_utils.dart';
import 'package:solar_icons/solar_icons.dart';

class GoalScreen extends StatefulWidget {
  const GoalScreen({super.key});

  @override
  State<GoalScreen> createState() => _GoalScreenState();
}

class _GoalScreenState extends State<GoalScreen> {
  static const Duration _goalListAnimationDuration = Duration(
    milliseconds: 260,
  );
  static const double _goalItemHeight = 90.0;
  static const List<String> _persianMonths = [
    'فروردین',
    'اردیبهشت',
    'خرداد',
    'تیر',
    'مرداد',
    'شهریور',
    'مهر',
    'آبان',
    'آذر',
    'دی',
    'بهمن',
    'اسفند',
  ];

  static const double _goalSheetItemExtent = 48;
  static const int _goalSheetVisibleWheelItems = 3;

  final List<Map<String, dynamic>> _goals = [];
  late final ScrollController _goalCardsScrollController;
  late final ScrollController _goalDotsScrollController;
  bool _isSyncingGoalScroll = false;

  @override
  void initState() {
    super.initState();
    _goalCardsScrollController = ScrollController();
    _goalDotsScrollController = ScrollController();

    _goalCardsScrollController.addListener(() {
      if (_isSyncingGoalScroll) return;
      if (!_goalDotsScrollController.hasClients) return;
      _isSyncingGoalScroll = true;
      _goalDotsScrollController.jumpTo(
        _goalCardsScrollController.offset.clamp(
          _goalDotsScrollController.position.minScrollExtent,
          _goalDotsScrollController.position.maxScrollExtent,
        ),
      );
      _isSyncingGoalScroll = false;
    });

    _goalDotsScrollController.addListener(() {
      if (_isSyncingGoalScroll) return;
      if (!_goalCardsScrollController.hasClients) return;
      _isSyncingGoalScroll = true;
      _goalCardsScrollController.jumpTo(
        _goalDotsScrollController.offset.clamp(
          _goalCardsScrollController.position.minScrollExtent,
          _goalCardsScrollController.position.maxScrollExtent,
        ),
      );
      _isSyncingGoalScroll = false;
    });
  }

  @override
  void dispose() {
    _goalCardsScrollController.dispose();
    _goalDotsScrollController.dispose();
    super.dispose();
  }

  Future<void> _openAddGoalModal({
    int? editIndex,
    Map<String, dynamic>? initialGoal,
  }) async {
    final today = Jalali.now();
    final rawInitialDate = initialGoal?['dueDate'] as Jalali? ?? today;
    final initialDate =
        _compareJalaliDate(rawInitialDate, today) < 0 ? today : rawInitialDate;
    final titleController = TextEditingController(
      text: initialGoal?['title']?.toString() ?? '',
    );
    final noteController = TextEditingController(
      text: initialGoal?['note']?.toString() ?? '',
    );
    var selectedDay = initialDate.day;
    var selectedMonth = initialDate.month;
    var selectedYear = initialDate.year;
    var noteLength = noteController.text.length;
    final years = [
      for (var year = initialDate.year - 4; year <= 1500; year++) year
    ];
    final dayController = FixedExtentScrollController(
      initialItem: selectedDay - 1,
    );
    final monthController = FixedExtentScrollController(
      initialItem: selectedMonth - 1,
    );
    final yearController = FixedExtentScrollController(
      initialItem: years.indexOf(selectedYear),
    );
    var isPickerDisposed = false;

    void jumpToWheelItem(FixedExtentScrollController controller, int item) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted || isPickerDisposed || !controller.hasClients) return;
        controller.jumpToItem(item);
      });
    }

    void clampSelectedDateToToday() {
      final selectedDate = Jalali(selectedYear, selectedMonth, selectedDay);
      if (_compareJalaliDate(selectedDate, today) >= 0) return;

      selectedDay = today.day;
      selectedMonth = today.month;
      selectedYear = today.year;
      jumpToWheelItem(dayController, selectedDay - 1);
      jumpToWheelItem(monthController, selectedMonth - 1);
      final yearIndex = years.indexOf(selectedYear);
      if (yearIndex >= 0) {
        jumpToWheelItem(yearController, yearIndex);
      }
    }

    final newGoal = await showReModalBottomSheet<Map<String, dynamic>>(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            final bottomInset = MediaQuery.of(context).viewInsets.bottom;
            final maxDay = Jalali(selectedYear, selectedMonth, 1).monthLength;
            if (selectedDay > maxDay) {
              selectedDay = maxDay;
              jumpToWheelItem(dayController, selectedDay - 1);
            }

            return Directionality(
              textDirection: TextDirection.rtl,
              child: AnimatedPadding(
                duration: const Duration(milliseconds: 220),
                curve: Curves.easeOutCubic,
                padding: EdgeInsets.only(bottom: bottomInset),
                child: SingleChildScrollView(
                  physics: const ClampingScrollPhysics(),
                  child: Container(
                    padding: const EdgeInsets.fromLTRB(32, 28, 32, 32),
                    decoration: const BoxDecoration(
                      color: AppColors.white,
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(32),
                        topRight: Radius.circular(32),
                      ),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        _buildGoalSheetHeader(context),
                        const SizedBox(height: 25),
                        ReTextField(
                          controller: titleController,
                          placeholder: 'عنوان هدف',
                          height: 56,
                          borderRadius: 32,
                          backgroundColor: AppColors.gray.withOpacity(
                            0.1,
                          ),
                          showFocusShadow: false,
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                        ),
                        const SizedBox(height: 42),
                        _buildGoalDatePicker(
                          years: years,
                          selectedDay: selectedDay,
                          selectedMonth: selectedMonth,
                          selectedYear: selectedYear,
                          dayController: dayController,
                          monthController: monthController,
                          yearController: yearController,
                          onDayChanged: (value) {
                            setModalState(() {
                              selectedDay = value;
                              clampSelectedDateToToday();
                            });
                          },
                          onMonthChanged: (value) {
                            setModalState(() {
                              selectedMonth = value;
                              final nextMaxDay = Jalali(
                                selectedYear,
                                selectedMonth,
                                1,
                              ).monthLength;
                              selectedDay = selectedDay.clamp(1, nextMaxDay);
                              clampSelectedDateToToday();
                            });
                          },
                          onYearChanged: (value) {
                            setModalState(() {
                              selectedYear = value;
                              final nextMaxDay = Jalali(
                                selectedYear,
                                selectedMonth,
                                1,
                              ).monthLength;
                              selectedDay = selectedDay.clamp(1, nextMaxDay);
                              clampSelectedDateToToday();
                            });
                          },
                        ),
                        const SizedBox(height: 34),
                        _buildGoalNoteField(
                          controller: noteController,
                          noteLength: noteLength,
                          onChanged: (value) {
                            setModalState(() => noteLength = value.length);
                          },
                        ),
                        const SizedBox(height: 36),
                        _buildGoalSheetActions(
                          context,
                          titleController: titleController,
                          noteController: noteController,
                          selectedDay: selectedDay,
                          selectedMonth: selectedMonth,
                          selectedYear: selectedYear,
                          existingGoal: initialGoal,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            );
          },
        );
      },
    );

    await Future<void>.delayed(const Duration(milliseconds: 350));
    titleController.dispose();
    noteController.dispose();
    isPickerDisposed = true;
    dayController.dispose();
    monthController.dispose();
    yearController.dispose();

    if (newGoal == null || !mounted) return;

    setState(() {
      if (editIndex != null &&
          editIndex >= 0 &&
          editIndex < _goals.length &&
          initialGoal != null) {
        _goals[editIndex] = newGoal;
      } else {
        _goals.insert(0, newGoal);
      }
    });

    if (_goalCardsScrollController.hasClients) {
      _goalCardsScrollController.animateTo(
        0,
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeOut,
      );
    }
    if (_goalDotsScrollController.hasClients) {
      _goalDotsScrollController.animateTo(
        0,
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeOut,
      );
    }
  }

  Widget _buildGoalSheetHeader(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        GestureDetector(
          onTap: () => Navigator.of(context).pop(),
          child: Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: AppColors.gray2, width: 1.5),
            ),
            child: const Icon(
              Icons.close,
              size: 20,
              color: AppColors.gray,
            ),
          ),
        ),
        const SizedBox(width: 16),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const ReText(
              'افزودن هدف',
              fontSize: 16,
              fontWeight: 1000,
              color: AppColors.black1,
            ),
            ReText(
              'هدف جدیدی برای خود مشخص کنید.',
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: AppColors.black1.withOpacity(0.5),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildGoalDatePicker({
    required List<int> years,
    required int selectedDay,
    required int selectedMonth,
    required int selectedYear,
    required FixedExtentScrollController dayController,
    required FixedExtentScrollController monthController,
    required FixedExtentScrollController yearController,
    required ValueChanged<int> onDayChanged,
    required ValueChanged<int> onMonthChanged,
    required ValueChanged<int> onYearChanged,
  }) {
    final days = [
      for (var day = 1;
          day <= Jalali(selectedYear, selectedMonth, 1).monthLength;
          day++)
        day
    ];

    return SizedBox(
      height: 184,
      child: Column(
        children: [
          const Row(
            textDirection: TextDirection.rtl,
            children: [
              Expanded(
                child: Center(
                  child: ReText(
                    'روز',
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: AppColors.black1,
                  ),
                ),
              ),
              Expanded(
                child: Center(
                  child:
                      ReText('ماه', fontSize: 13, fontWeight: FontWeight.w600),
                ),
              ),
              Expanded(
                child: Center(
                  child:
                      ReText('سال', fontSize: 13, fontWeight: FontWeight.w600),
                ),
              ),
            ],
          ),
          Expanded(
            child: Row(
              textDirection: TextDirection.rtl,
              children: [
                Expanded(
                  child: _buildWheelColumn(
                    controller: dayController,
                    itemCount: days.length,
                    onSelected: (index) => onDayChanged(index + 1),
                    selectedChild: ReText(
                      selectedDay.toString(),
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      color: AppColors.white,
                      textAlign: TextAlign.center,
                    ),
                    selectedDecoration: BoxDecoration(
                      color: AppColors.black1,
                      borderRadius: BorderRadius.circular(28),
                    ),
                    itemBuilder: (index) => ReText(
                      days[index].toString(),
                      fontSize: 13,
                      fontWeight: FontWeight.w400,
                      color: _wheelItemColor(
                          (index + 1) == selectedDay, index, selectedDay - 1),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
                _buildDateDivider(),
                Expanded(
                  child: _buildWheelColumn(
                    controller: monthController,
                    itemCount: _persianMonths.length,
                    selectedWidth: 100,
                    onSelected: (index) => onMonthChanged(index + 1),
                    selectedChild: ReText(
                      _persianMonths[selectedMonth - 1],
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      color: AppColors.black1,
                      textAlign: TextAlign.center,
                    ),
                    selectedDecoration: BoxDecoration(
                      color: AppColors.white,
                      borderRadius: BorderRadius.circular(28),
                      border: Border.all(color: AppColors.gray2, width: 1.5),
                    ),
                    itemBuilder: (index) => ReText(
                      _persianMonths[index],
                      fontSize: 13,
                      fontWeight: FontWeight.w400,
                      color: _wheelItemColor((index + 1) == selectedMonth,
                          index, selectedMonth - 1),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
                _buildDateDivider(),
                Expanded(
                  child: _buildWheelColumn(
                    controller: yearController,
                    itemCount: years.length,
                    onSelected: (index) => onYearChanged(years[index]),
                    selectedChild: ReText(
                      selectedYear.toString(),
                      fontSize: 16,
                      fontWeight: FontWeight.w400,
                      color: AppColors.black1,
                      textAlign: TextAlign.center,
                    ),
                    selectedDecoration: BoxDecoration(
                      color: AppColors.white,
                      borderRadius: BorderRadius.circular(28),
                      border: Border.all(color: AppColors.gray2, width: 1.5),
                    ),
                    itemBuilder: (index) => ReText(
                      years[index].toString(),
                      fontSize: 13,
                      fontWeight: FontWeight.w400,
                      color: _wheelItemColor(years[index] == selectedYear,
                          index, years.indexOf(selectedYear)),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildWheelColumn({
    required FixedExtentScrollController controller,
    required int itemCount,
    required ValueChanged<int> onSelected,
    required Widget Function(int index) itemBuilder,
    required Widget selectedChild,
    required BoxDecoration selectedDecoration,
    double selectedWidth = 66,
  }) {
    return Center(
      child: SizedBox(
        height: _goalSheetItemExtent * _goalSheetVisibleWheelItems,
        child: Stack(
          alignment: Alignment.center,
          children: [
            ListWheelScrollView.useDelegate(
              controller: controller,
              physics: const FixedExtentScrollPhysics(),
              itemExtent: _goalSheetItemExtent,
              diameterRatio: 10,
              perspective: 0.001,
              overAndUnderCenterOpacity: 1,
              onSelectedItemChanged: onSelected,
              childDelegate: ListWheelChildBuilderDelegate(
                childCount: itemCount,
                builder: (context, index) {
                  return Center(child: itemBuilder(index));
                },
              ),
            ),
            IgnorePointer(
              child: Container(
                width: selectedWidth,
                height: 48,
                alignment: Alignment.center,
                decoration: selectedDecoration,
                child: selectedChild,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDateDivider() {
    return Container(
      width: 1,
      margin: const EdgeInsets.only(top: 2, bottom: 10),
      color: AppColors.gray2.withOpacity(0.45),
    );
  }

  Color _wheelItemColor(bool isSelected, int index, int selectedIndex) {
    if (isSelected) return Colors.transparent;
    return (index - selectedIndex).abs() == 1
        ? AppColors.gray
        : AppColors.gray2;
  }

  Widget _buildGoalNoteField({
    required TextEditingController controller,
    required int noteLength,
    required ValueChanged<String> onChanged,
  }) {
    return Stack(
      children: [
        ReTextField(
          controller: controller,
          placeholder: 'یادداشت',
          maxLines: 4,
          maxLength: 200,
          height: 96,
          borderRadius: 32,
          backgroundColor: AppColors.gray2,
          contentPadding: const EdgeInsets.fromLTRB(52, 20, 16, 30),
          textInputAction: TextInputAction.done,
          showFocusShadow: false,
          fontSize: 13,
          textColor: AppColors.black1.withOpacity(0.5),
          fontWeight: FontWeight.w600,
          onChanged: onChanged,
        ),
        Positioned(
          left: 16,
          bottom: 14,
          child: ReText(
            '${noteLength.clamp(0, 200)}/200',
            fontSize: 13,
            fontWeight: FontWeight.w600,
            color: AppColors.black1.withOpacity(0.5),
            textDirection: TextDirection.ltr,
          ),
        ),
      ],
    );
  }

  int _compareJalaliDate(Jalali a, Jalali b) {
    if (a.year != b.year) return a.year.compareTo(b.year);
    if (a.month != b.month) return a.month.compareTo(b.month);
    return a.day.compareTo(b.day);
  }

  Widget _buildRemainingTimeText({
    required Jalali dueDate,
    required Color valueColor,
    required double valueFontSize,
    required double unitFontSize,
    FontWeight valueFontWeight = FontWeight.w600,
    FontWeight unitFontWeight = FontWeight.w600,
    bool valueFirst = false,
  }) {
    final remaining = _goalRemainingTime(dueDate);
    final value = ReText(
      remaining.value.toString(),
      fontSize: valueFontSize,
      fontWeight: valueFontWeight,
      color: valueColor,
      textDirection: TextDirection.ltr,
    );
    final unit = ReText(
      remaining.unit,
      fontSize: unitFontSize,
      fontWeight: unitFontWeight,
      color: AppColors.gray,
    );

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: valueFirst
          ? [value, const SizedBox(width: 4), unit]
          : [unit, const SizedBox(width: 4), value],
    );
  }

  _GoalRemainingTime _goalRemainingTime(Jalali dueDate) {
    final remainingDays = _goalRemainingDays(dueDate);
    if (remainingDays == 1) {
      final now = DateTime.now();
      final dueDateTime = dueDate.toDateTime();
      final dueDay = DateTime(
        dueDateTime.year,
        dueDateTime.month,
        dueDateTime.day,
      );
      final remainingHours = dueDay.difference(now).inHours;

      return _GoalRemainingTime(
        value: math.max(1, remainingHours),
        unit: 'ساعت باقی مانده',
      );
    }

    return _GoalRemainingTime(
      value: remainingDays,
      unit: 'روز باقی مانده',
    );
  }

  void _submitGoal(
    BuildContext context, {
    required TextEditingController titleController,
    required TextEditingController noteController,
    required int selectedDay,
    required int selectedMonth,
    required int selectedYear,
    Map<String, dynamic>? existingGoal,
  }) {
    final title = titleController.text.trim();
    if (title.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: ReText(
            'عنوان هدف را وارد کنید',
            color: AppColors.white,
            fontSize: 14,
            fontWeight: FontWeight.w600,
          ),
        ),
      );
      return;
    }

    final dueDate = Jalali(selectedYear, selectedMonth, selectedDay);
    final createdDate = existingGoal?['createdDate'] as Jalali? ?? Jalali.now();
    final totalDays = _goalDaysBetween(createdDate, dueDate);
    Navigator.of(context).pop(
      <String, dynamic>{
        'title': title,
        'note': noteController.text.trim(),
        'dueDate': dueDate,
        'createdDate': createdDate,
        'totalDays': math.max(1, totalDays),
        'color': existingGoal?['color'] as Color? ??
            (_goals.length.isEven ? AppColors.primary : AppColors.secondary),
      },
    );
  }

  Widget _buildGoalSheetActions(
    BuildContext context, {
    required TextEditingController titleController,
    required TextEditingController noteController,
    required int selectedDay,
    required int selectedMonth,
    required int selectedYear,
    Map<String, dynamic>? existingGoal,
  }) {
    return Row(
      textDirection: TextDirection.rtl,
      children: [
        SizedBox(
          width: 118,
          height: 58,
          child: ReButton(
            onPressed: () => Navigator.of(context).pop(),
            text: 'لغو',
            icon: Icons.close,
            textDirection: TextDirection.ltr,
            isOutlined: true,
            background: AppColors.white,
            color: AppColors.gray2,
            textColor: AppColors.black1,
            borderRadius: 32,
            fontSize: 16,
            iconSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: SizedBox(
            height: 58,
            child: ReButton(
              onPressed: () => _submitGoal(
                context,
                titleController: titleController,
                noteController: noteController,
                selectedDay: selectedDay,
                selectedMonth: selectedMonth,
                selectedYear: selectedYear,
                existingGoal: existingGoal,
              ),
              text: 'افزودن',
              icon: Icons.add,
              textDirection: TextDirection.ltr,
              background: AppColors.primary,
              textColor: AppColors.white,
              borderRadius: 32,
              fontSize: 16,
              iconSize: 16,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ],
    );
  }

  int _goalRemainingDays(Jalali dueDate) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final dueDateTime = dueDate.toDateTime();
    final dueDay = DateTime(
      dueDateTime.year,
      dueDateTime.month,
      dueDateTime.day,
    );

    return math.max(0, dueDay.difference(today).inDays);
  }

  int _goalDaysBetween(Jalali startDate, Jalali endDate) {
    final startDateTime = startDate.toDateTime();
    final endDateTime = endDate.toDateTime();
    final startDay = DateTime(
      startDateTime.year,
      startDateTime.month,
      startDateTime.day,
    );
    final endDay = DateTime(
      endDateTime.year,
      endDateTime.month,
      endDateTime.day,
    );

    return math.max(0, endDay.difference(startDay).inDays);
  }

  String _formatGoalDate(Jalali date) {
    return '${date.year}/${date.month.toString().padLeft(2, '0')}/${date.day.toString().padLeft(2, '0')}';
  }

  double _goalProgress(Map<String, dynamic> goal) {
    final dueDate = goal['dueDate'] as Jalali;
    final totalDays = goal['totalDays'] as int? ??
        _goalDaysBetween(
          goal['createdDate'] as Jalali? ?? Jalali.now(),
          dueDate,
        );
    final remainingDays = _goalRemainingDays(dueDate);

    if (totalDays <= 0) return 1;
    return ((totalDays - remainingDays) / totalDays).clamp(0.0, 1.0);
  }

  void _deleteGoal(int index) {
    if (index < 0 || index >= _goals.length) return;

    setState(() {
      _goals.removeAt(index);
    });
  }

  Future<void> _openGoalDetailsModal(int index) async {
    if (index < 0 || index >= _goals.length) return;

    await showReModalBottomSheet<void>(
      context: context,
      builder: (sheetContext) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            if (index >= _goals.length) return const SizedBox.shrink();

            final goal = _goals[index];
            final dueDate = goal['dueDate'] as Jalali;
            final progress = _goalProgress(goal);
            final note = (goal['note']?.toString().trim().isNotEmpty ?? false)
                ? goal['note'].toString().trim()
                : 'برای این هدف هنوز یادداشتی ثبت نشده است.';

            return Directionality(
              textDirection: TextDirection.rtl,
              child: Container(
                padding: const EdgeInsets.fromLTRB(44, 32, 44, 48),
                decoration: const BoxDecoration(
                  color: AppColors.white,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(32),
                    topRight: Radius.circular(32),
                  ),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        GestureDetector(
                          behavior: HitTestBehavior.opaque,
                          onTap: () => Navigator.of(sheetContext).pop(),
                          child: Container(
                            width: 48,
                            height: 48,
                            decoration: BoxDecoration(
                              color: AppColors.white,
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: AppColors.gray2,
                                width: 1.5,
                              ),
                            ),
                            child: const Icon(
                              Icons.close,
                              color: AppColors.gray,
                              size: 12,
                            ),
                          ),
                        ),
                        const SizedBox(width: 16),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            ReText(
                              goal['title']?.toString() ?? '',
                              fontSize: 16,
                              fontWeight: 1000,
                              color: AppColors.black1,
                              maxLines: 2,
                            ),
                            const SizedBox(height: 4),
                            ReText(
                              _formatGoalDate(dueDate),
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                              color: AppColors.gray,
                              textDirection: TextDirection.ltr,
                            ),
                          ],
                        ),
                      ],
                    ),
                    Container(
                      height: 1,
                      color: AppColors.gray2,
                      margin: const EdgeInsets.only(top: 25, bottom: 25),
                    ),
                    Align(
                      alignment: Alignment.topRight,
                      child: ReText(
                        note,
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: AppColors.gray,
                        lineHeight: 1.85,
                        maxLines: 3,
                        textAlign: TextAlign.right,
                      ),
                    ),
                    const SizedBox(height: 25),
                    Row(
                      textDirection: TextDirection.rtl,
                      children: [
                        Expanded(
                          child: SizedBox(
                            height: 3,
                            child: LayoutBuilder(
                              builder: (context, constraints) {
                                return Stack(
                                  alignment: Alignment.center,
                                  children: [
                                    Container(
                                      height: 1,
                                      decoration: BoxDecoration(
                                        color: AppColors.gray2,
                                        borderRadius:
                                            BorderRadius.circular(100),
                                      ),
                                    ),
                                    Align(
                                      alignment: Alignment.centerRight,
                                      child: Container(
                                        width: constraints.maxWidth * progress,
                                        height: 6,
                                        decoration: BoxDecoration(
                                          color: AppColors.primary,
                                          borderRadius:
                                              BorderRadius.circular(100),
                                        ),
                                      ),
                                    ),
                                  ],
                                );
                              },
                            ),
                          ),
                        ),
                        const SizedBox(width: 18),
                        _buildRemainingTimeText(
                          dueDate: dueDate,
                          valueColor: AppColors.black1,
                          valueFontSize: 13,
                          unitFontSize: 13,
                          valueFontWeight: FontWeight.w700,
                          unitFontWeight: FontWeight.w400,
                          valueFirst: true,
                        ),
                      ],
                    ),
                    const SizedBox(height: 25),
                    Row(
                      textDirection: TextDirection.rtl,
                      children: [
                        GestureDetector(
                          behavior: HitTestBehavior.opaque,
                          onTap: () {
                            _deleteGoal(index);
                            Navigator.of(sheetContext).pop();
                          },
                          child: Container(
                            width: 56,
                            height: 56,
                            decoration: BoxDecoration(
                              color: AppColors.white,
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: AppColors.gray2,
                                width: 1,
                              ),
                            ),
                            child: const Icon(
                              IconsaxPlusBroken.trash,
                              color: AppColors.black1,
                              size: 18,
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: SizedBox(
                            width: 118,
                            height: 58,
                            child: ReButton(
                              onPressed: () {
                                final goalToEdit =
                                    Map<String, dynamic>.from(goal);
                                Navigator.of(sheetContext).pop();
                                Future<void>.delayed(
                                  const Duration(milliseconds: 250),
                                  () {
                                    if (!mounted) return;
                                    _openAddGoalModal(
                                      editIndex: index,
                                      initialGoal: goalToEdit,
                                    );
                                  },
                                );
                              },
                              text: 'ویرایش',
                              icon: SolarIconsOutline.penNewSquare,
                              textDirection: TextDirection.ltr,
                              isOutlined: true,
                              background: AppColors.white,
                              color: AppColors.gray2,
                              textColor: AppColors.black1,
                              borderRadius: 32,
                              fontSize: 16,
                              iconSize: 18,
                              iconColor: AppColors.black1,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildGoalTile(Map<String, dynamic> goal, int index) {
    final dueDate = goal['dueDate'] as Jalali;
    final color = goal['color'] as Color? ?? AppColors.primary;

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => _openGoalDetailsModal(index),
      child: Container(
        height: 72,
        decoration: BoxDecoration(
          color: AppColors.white,
          borderRadius: BorderRadius.circular(100),
          boxShadow: [
            BoxShadow(
              color: AppColors.black1.withOpacity(0.04),
              blurRadius: 80,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Row(
          children: [
            const Icon(
              Icons.arrow_back_ios,
              size: 12,
              color: AppColors.gray,
            ).lMargin(24),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.only(right: 24, left: 12),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    ReText(
                      goal['title']?.toString() ?? '',
                      fontSize: 14,
                      fontWeight: FontWeight.w900,
                      color: AppColors.black1,
                      maxLines: 1,
                    ),
                    const SizedBox(height: 2),
                    _buildRemainingTimeText(
                      dueDate: dueDate,
                      valueColor: color,
                      valueFontSize: 13,
                      unitFontSize: 10,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildGoalList() {
    if (_goals.isEmpty) {
      return ReEmptyList(
        imageWidth: 220,
        onTap: _openAddGoalModal,
        title: 'هنوز هدفی مشخص نکردی!',
        subtitle: 'برای افزودن هدف روی + کلیک کنید.',
        imagePath: 'assets/images/empty_list_goal.png',
      );
    }

    return Align(
      alignment: Alignment.topCenter,
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 760),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: ListView.builder(
                controller: _goalCardsScrollController,
                padding: const EdgeInsets.fromLTRB(32, 0, 0, 24),
                itemCount: _goals.length,
                itemBuilder: (_, index) => AnimatedContainer(
                  duration: _goalListAnimationDuration,
                  curve: Curves.easeOutCubic,
                  height: _goalItemHeight,
                  alignment: Alignment.center,
                  child: _buildGoalTile(_goals[index], index),
                ),
              ),
            ),
            SizedBox(
              width: 68,
              child: ListView.builder(
                controller: _goalDotsScrollController,
                padding: const EdgeInsets.only(top: 0, bottom: 24, right: 8),
                itemCount: _goals.length,
                itemBuilder: (_, index) {
                  final color =
                      _goals[index]['color'] as Color? ?? AppColors.primary;
                  return AnimatedContainer(
                    duration: _goalListAnimationDuration,
                    curve: Curves.easeOutCubic,
                    height: _goalItemHeight,
                    child: ReTimelineDot(
                      showTopLine: index != 0,
                      showBottomLine: index != _goals.length - 1,
                      isDone: true,
                      height: _goalItemHeight,
                      width: 56,
                      circleSize: 35,
                      innerCircleSize: 32,
                      lineColor: AppColors.black1.withOpacity(0.2),
                      activeBackgroundColor: color.withOpacity(0.12),
                      innerPadding: const EdgeInsets.all(5),
                      child: Icon(
                        SolarIconsBold.target,
                        color: color,
                        size: 16,
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.gray1,
      bottomNavigationBar: AppBottomNavigationBar(
        currentIndex: 2,
        onTap: (index) => navigateToIndex(context, index, 2),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Container(
              decoration: const BoxDecoration(
                color: AppColors.white,
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(48),
                  bottomRight: Radius.circular(48),
                ),
              ),
              child: Column(
                children: [
                  reAppHeader(
                    'اهداف',
                    prefixIcon: GestureDetector(
                      child: const SizedBox(
                        width: 48,
                        height: 48,
                        child: Icon(
                          SolarIconsOutline.bell,
                          size: 24,
                        ),
                      ),
                    ),
                    suffixIcon: GestureDetector(
                      child: const SizedBox(
                        width: 48,
                        height: 48,
                        child: Icon(
                          SolarIconsOutline.history,
                          size: 24,
                        ),
                      ),
                    ),
                  ).bMargin(24)
                ],
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ReButton(
                  onPressed: _openAddGoalModal,
                  text: 'افزودن هدف',
                  textDirection: TextDirection.ltr,
                  icon: Icons.add,
                  iconColor: AppColors.primary,
                  color: AppColors.gray2,
                  iconSize: 18,
                  isOutlined: true,
                  background: AppColors.gray1,
                  textColor: AppColors.black1,
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                ).sizedBox(
                  height: 40,
                  width: 132,
                ),
                const ReText(
                  'اهداف شما',
                  fontSize: 16,
                  fontWeight: FontWeight.w900,
                ).tMargin(2)
              ],
            ).hMargin(32).tMargin(16).bMargin(8),
            Expanded(
              child: _buildGoalList(),
            ),
          ],
        ),
      ),
    );
  }
}

class _GoalRemainingTime {
  const _GoalRemainingTime({
    required this.value,
    required this.unit,
  });

  final int value;
  final String unit;
}
