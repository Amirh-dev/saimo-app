import 'package:flutter/material.dart';
import 'package:simo_learn/presentation/widgets/re_image.dart';
import 'package:simo_learn/presentation/widgets/re_text.dart';
import 'package:simo_learn/utils/colors.dart';
import 'package:simo_learn/utils/enums.dart';
import 'package:simo_learn/utils/extentions.dart';

Row authHeaderWidget(
  BuildContext context, {
  required Enum authType,
  VoidCallback? onBack,
  bool backButton = false,
}) {
  return Row(
    mainAxisAlignment: MainAxisAlignment.center,
    crossAxisAlignment: CrossAxisAlignment.end,
    children: [
      ReImage(
        authType == AuthMode.register
            ? 'assets/images/register.png'
            : authType == AuthMode.login
                ? 'assets/images/login.png'
                : 'assets/images/login.png',
        width: authType == AuthMode.login || authType == AuthMode.otpCode
            ? 145.fs
            : 170,
        height: 160.fs,
        fit: BoxFit.fitWidth,
      ),
      const Spacer(),
      Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          backButton
              ? GestureDetector(
                  onTap: onBack ?? () => context.back(),
                  child: Container(
                    width: 48,
                    height: 48,
                    margin: const EdgeInsets.only(bottom: 16),
                    decoration: BoxDecoration(
                        border: Border.all(color: const Color(0x23232b1a)),
                        borderRadius: BorderRadius.circular(100)),
                    child: const Icon(
                      Icons.arrow_forward,
                      size: 18,
                      color: AppColors.gray,
                    ).hMargin(15).vMargin(15),
                  ),
                )
              : const SizedBox(),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              ReText(
                authType == AuthMode.register
                    ? 'ثبت نام'
                    : authType == AuthMode.login
                        ? 'ورود به حساب'
                        : 'کد تایید',
                fontSize: 14.fs,
                fontWeight: FontWeight.w900,
              ),
              ReText(
                authType == AuthMode.register
                    ? 'یک حساب ایجاد کنید.'
                    : authType == AuthMode.login
                        ? 'به حساب کاربری خود وارد شوید.'
                        : 'کد تایید ارسال شده را وارد کنید.',
                fontSize: 11.fs,
                color: AppColors.gray,
                fontWeight: FontWeight.w600,
              ).tMargin(2)
            ],
          )
        ],
      ),
    ],
  );
}
