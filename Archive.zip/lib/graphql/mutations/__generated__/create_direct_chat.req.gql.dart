// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint

// ignore_for_file: no_leading_underscores_for_library_prefixes
import 'package:built_value/built_value.dart';
import 'package:built_value/serializer.dart';
import 'package:ferry_exec/ferry_exec.dart' as _i1;
import 'package:gql_exec/gql_exec.dart' as _i4;
import 'package:simo_learn/graphql/__generated__/serializers.gql.dart' as _i6;
import 'package:simo_learn/graphql/mutations/__generated__/create_direct_chat.ast.gql.dart'
    as _i5;
import 'package:simo_learn/graphql/mutations/__generated__/create_direct_chat.data.gql.dart'
    as _i2;
import 'package:simo_learn/graphql/mutations/__generated__/create_direct_chat.var.gql.dart'
    as _i3;

part 'create_direct_chat.req.gql.g.dart';

abstract class GCreateDirectChatReq
    implements
        Built<GCreateDirectChatReq, GCreateDirectChatReqBuilder>,
        _i1.OperationRequest<_i2.GCreateDirectChatData,
            _i3.GCreateDirectChatVars> {
  GCreateDirectChatReq._();

  factory GCreateDirectChatReq(
          [void Function(GCreateDirectChatReqBuilder b) updates]) =
      _$GCreateDirectChatReq;

  static void _initializeBuilder(GCreateDirectChatReqBuilder b) => b
    ..operation = _i4.Operation(
      document: _i5.document,
      operationName: 'CreateDirectChat',
    )
    ..executeOnListen = true;

  @override
  _i3.GCreateDirectChatVars get vars;
  @override
  _i4.Operation get operation;
  @override
  _i4.Request get execRequest => _i4.Request(
        operation: operation,
        variables: vars.toJson(),
        context: context ?? const _i4.Context(),
      );

  @override
  String? get requestId;
  @override
  @BuiltValueField(serialize: false)
  _i2.GCreateDirectChatData? Function(
    _i2.GCreateDirectChatData?,
    _i2.GCreateDirectChatData?,
  )? get updateResult;
  @override
  _i2.GCreateDirectChatData? get optimisticResponse;
  @override
  String? get updateCacheHandlerKey;
  @override
  Map<String, dynamic>? get updateCacheHandlerContext;
  @override
  _i1.FetchPolicy? get fetchPolicy;
  @override
  bool get executeOnListen;
  @override
  @BuiltValueField(serialize: false)
  _i4.Context? get context;
  @override
  _i2.GCreateDirectChatData? parseData(Map<String, dynamic> json) =>
      _i2.GCreateDirectChatData.fromJson(json);

  @override
  Map<String, dynamic> varsToJson() => vars.toJson();

  @override
  Map<String, dynamic> dataToJson(_i2.GCreateDirectChatData data) =>
      data.toJson();

  @override
  _i1.OperationRequest<_i2.GCreateDirectChatData, _i3.GCreateDirectChatVars>
      transformOperation(_i4.Operation Function(_i4.Operation) transform) =>
          this.rebuild((b) => b..operation = transform(operation));

  static Serializer<GCreateDirectChatReq> get serializer =>
      _$gCreateDirectChatReqSerializer;

  Map<String, dynamic> toJson() => (_i6.serializers.serializeWith(
        GCreateDirectChatReq.serializer,
        this,
      ) as Map<String, dynamic>);

  static GCreateDirectChatReq? fromJson(Map<String, dynamic> json) =>
      _i6.serializers.deserializeWith(
        GCreateDirectChatReq.serializer,
        json,
      );
}
