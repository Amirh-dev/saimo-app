void startGlobalTimer(){

}